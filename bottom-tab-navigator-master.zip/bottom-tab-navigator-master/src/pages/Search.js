import React from 'react';

const Search = (props) => {

  return (
    <div>
      Search
    </div>
  )
};

export default Search;
